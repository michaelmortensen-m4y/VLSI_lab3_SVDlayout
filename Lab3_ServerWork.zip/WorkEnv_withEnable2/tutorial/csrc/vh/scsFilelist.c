#include "stdio.h"
#ifdef __cplusplus
extern "C" {
#endif
extern char at_least_one_object_file;
extern void *kernel_scs_file_ht_new(const void *, int);
extern int kernel_scs_file_ht_get(void *, const char *, int *);
extern int  strcmp(const char*, const char*);
  typedef struct {
    char* dFileName;
  } lPkgFileInfoStruct;

  typedef struct {
    char* dFileName;
    char* dRealFileName;
    long dFileOffset;
    int dFileSize;
    int dFileModTime;
    unsigned int simFlag;
  } lFileInfoStruct;

static int lNumOfScsFiles;
  static lFileInfoStruct lFInfoArr[] = {
  {"synopsys_sim.setup_0", "/apps/synopsys/VCS-MX/D-2010.06/bin/synopsys_sim.setup", 6647, 3912, 1274759299, 0},
  {"./64/TBTV_SVD.sim", "", 0, 6647, 0, 1},
  {"amd64/packages/IEEE/lib/64/STD_LOGIC_SIGNED__.sim", "", 10559, 112638, 0, 0},
  {"amd64/packages/IEEE/lib/64/STD_LOGIC_SIGNED.sim", "", 123197, 53440, 0, 0},
  {"amd64/packages/IEEE/lib/64/STD_LOGIC_TEXTIO__.sim", "", 176637, 215512, 0, 0},
  {"amd64/packages/IEEE/lib/64/STD_LOGIC_TEXTIO.sim", "", 392149, 37757, 0, 0},
  {"simv.daidir/scsim.db.dir/DUMMY_MHDL_CFG_TBTV_SVD.sim", "", 429906, 18078, 0, 0},
  {"./64/TBTV_SVD__BEHAVIOR.sim", "", 447984, 41684, 0, 1},
  {"./64/SVD.sim", "", 489668, 36871, 0, 0},
  {"./64/SVD__MODULE.sim", "", 526539, 17286, 0, 0},

  };
  static lPkgFileInfoStruct lPkgFileInfoArr[] = {
  {"amd64/packages/IEEE/lib/64/STD_LOGIC_SIGNED__.sim"},
  {"amd64/packages/IEEE/lib/64/STD_LOGIC_TEXTIO__.sim"},

  };
int gGetFileInfo(char* xFileName, long xTimeStamp, long* xFileOffsetPtr, int* xFileSizePtr, int xCheckInPkgSimFiles,  char **xRealFileName)
{
  int j, lNumOfPkgSimFiles;
  static void *ht = 0;
  static int i = 0;
  static int k = 0;
at_least_one_object_file = 1;
  lNumOfScsFiles = 10;
  lNumOfPkgSimFiles = 2;
  if (xCheckInPkgSimFiles)
  {
     for (j = 0; j < lNumOfPkgSimFiles; j++)
     {
       char* lFName;
       lFName = lPkgFileInfoArr[k].dFileName;
       if (strcmp(lFName, xFileName) == 0)
           return 0;
       k = (k + 1) % lNumOfPkgSimFiles;
     }
     return 1;
  }
  if (!ht)
  {
    ht  = kernel_scs_file_ht_new(lFInfoArr, lNumOfScsFiles);
  }
  if (ht && (kernel_scs_file_ht_get(ht, xFileName, &i) == 0))
  { /* found it! The indicator 'i' was set properly. */
    if (xRealFileName)
        *xRealFileName = lFInfoArr[i].dRealFileName;
    *xFileSizePtr = lFInfoArr[i].dFileSize;
    *xFileOffsetPtr = lFInfoArr[i].dFileOffset;
    return 0;
  }
  return 1;
}
int getNextSimFile(char **fn, long *offset)
{
  static int cur;
  for ( ; cur < lNumOfScsFiles; ) {
    if (!lFInfoArr[cur].simFlag) {
      cur++;
      continue;
    }
    *fn = lFInfoArr[cur].dFileName;
    *offset = lFInfoArr[cur].dFileOffset;
    cur++;
    return 1;
  }
  return 0;
}

#ifdef __cplusplus
}
#endif
