#include "scscomm.h"
#ifdef __cplusplus
extern "C" {
#endif
extern char* strcpy(char*, const char*);
void scsim_comm_genfunc(scsim_communication_data_t *s) {
   s->worklibPath       = (char *) sc_mem_malloc(5);
   strcpy(s->worklibPath, "WORK");
   s->entityName        = (char *) sc_mem_malloc(24);
   strcpy(s->entityName,  "DUMMY_MHDL_CFG_TBTV_SVD");
   s->architectureName  = (char *) 0;
   s->designUnitType = 19;
   s->topSimFileName    = (char *) sc_mem_malloc(36);
   strcpy(s->topSimFileName, "DEFAULT.DUMMY_MHDL_CFG_TBTV_SVD.sim");
   s->timebase = 2;
   s->ignorelowres = 1;
   s->timebase_str      = (char *) sc_mem_malloc(3);
   strcpy(s->timebase_str, "NS");
   s->tres_str      = (char *) sc_mem_malloc(5);
   strcpy(s->tres_str, "1 PS");
   s->tres_time = 1;
   s->tres_timebase = 1;
   s->textio_timebase_unit = 0;
  s->upf_enabled = 0;
   s->isMixedHDL = 1;
   s->mhdlDatVerilog = 0;
   s->partitionFileName = (char *) 0;
   s->genericsFileName = (char *) 0;
   s->cmDirName  = (char *) sc_mem_malloc(9);
   strcpy(s->cmDirName, "simv.vdb");
   s->cmReportName = (char *) 0;
   s->isCovXmlDb  = 1;
   s->cmLogName = (char *) 0;
   s->monsigsFileCount  = 0;
   s->monsigsFileNames  = (char **) 0;
   s->vhpiLibStringCount = 0;
   s->vhpiLibStrings     = (char **) 0;
   s->UserName = (char *) sc_mem_malloc(8);
   strcpy(s->UserName, "s144031");
   s->CreationDate = (char *) sc_mem_malloc(25);
   strcpy(s->CreationDate, "Sun May  6 13:33:11 2018");
   s->Hostname = (char *) sc_mem_malloc(16);
   strcpy(s->Hostname, "eda4.imm.dtu.dk");
   s->SciroccoVersion = (char *) 0;
   s->CompilerName = (char *) sc_mem_malloc(4);
   strcpy(s->CompilerName, "gcc");
   s->CompilerVersion = (char *) sc_mem_malloc(39);
   strcpy(s->CompilerVersion, "GNUC 4.4.7 20120313 (Red Hat 4.4.7-18)");
   s->CompilerOptions = (char *) sc_mem_malloc(6);
   strcpy(s->CompilerOptions, "-c -O");
   s->LoaderName = (char *) sc_mem_malloc(4);
   strcpy(s->LoaderName, "g++");
   s->LoaderVersion = (char *) 0;
   s->LoaderOptions = (char *) sc_mem_malloc(17);
   strcpy(s->LoaderOptions, "-Wl,-E -lpthread");
   s->ElaborationOptions = (char *) sc_mem_malloc(83);
   strcpy(s->ElaborationOptions, "-full64 -debug -sdf typ:tbtv_SVD/UUT:svd-layout.sdf tbtv_SVD +neg_tchk +sdfverbose");
   s->VhdlOptions = (char *) sc_mem_malloc(192);
   strcpy(s->VhdlOptions, "-mxunielab -uni_make -nc -uum -vhtop WORK.dummy_mhdl_cfg_TBTV_SVD -elaboration_options /tmp/vcs_20180506113309_29226/elaboptfile_29226 -cm_xmldb -debug 3 -sdf typ:tbtv_SVD/UUT:svd-layout.sdf ");
   s->VerilogOptions = (char *) 0;
   s->PartitionCount  = 0;
   s->Partitions  = (char **) 0;
   s->twoState = 0;
   s->perf = 1;
   s->event_perf_mode = 14;
   s->db = 1;
   s->hasOvaDummyTop = 0;
   s->isInterpreted = 0;
   s->platformVersion = (char *) sc_mem_malloc(33);
   strcpy(s->platformVersion, "Linux 2.6.32-696.23.1.el6.x86_64");
   s->platform = (char *) sc_mem_malloc(6);
   strcpy(s->platform, "amd64");
   s->vcsHome = (char *) sc_mem_malloc(32);
   strcpy(s->vcsHome, "/apps/synopsys/VCS-MX/D-2010.06");
   s->m_total_processes = 0;
   s->verWork = (char *) sc_mem_malloc(12);
   strcpy(s->verWork, "simv.daidir");
   s->scsimCompileDirName  = (char *) sc_mem_malloc(64);
   strcpy(s->scsimCompileDirName, "/home/s144031/Desktop/MicData/Lab3/WorkEnd_withEnable2/tutorial");
   s->MhdlVerilogTopCount  = 0;
   s->MhdlVerilogTopNames  = (char **) 0;
   s->MhdlVhdlTopCount  = 1;
   s->MhdlVhdlTopNames = (char **) sc_mem_malloc(8*1);
   s->MhdlVhdlTopNames[0] = "WORK.dummy_mhdl_cfg_TBTV_SVD";
   s->unifiedUseMod = 1;
   s->svaBindEnable = 0;
   s->isSlave = 0;
   s->lic_scsi = 0;
   s->isScsfpga = 0;
   s->mtvh = 0;
   s->pvmx = 0;
   s->vhdlthreads = 2;
   s->isUCLI = 0;
   s->isGUI = 0;
   s->smart_analysis = 0;
   s->debugLevel = 3;
   s->vdbgWatch = 0;
   s->isFsdbSet = 0;
   s->isFsdbOldSet = 0;
   s->ScsWorkDir = (char *) sc_mem_malloc(64);
   strcpy(s->ScsWorkDir, "/home/s144031/Desktop/MicData/Lab3/WorkEnd_withEnable2/tutorial");
   s->sp_mem_size = 0;
   s->proc_split_num = 0;
   s->LcaLicenseEnabled = 0;
   s->fProfileNew = 0;
   s->accessCheck = 0;
   s->newProfArgs = (char *) 0;
   s->mhdl_root_net_opt = 0;
   s->mhdl_alias_highconn = 0;
   s->mxunielab = 1;
   s->withcheck = 0;
    s->dataBaseDirName = (char *) sc_mem_malloc(25);
    strcpy(s->dataBaseDirName, "simv.daidir/scsim.db.dir");
}

int scsim_comm_is_slave() {
   return 0;
}

#include "runtime.h"

extern int g_dynamic_phases;
extern int g_pvhdl;
extern int g_pvhdl2cdl;

int ctl_Simulate()
{
    return 0;
}

int pmhdl_Simulate()
{
     return 0;}

int mhdl_Simulate()
{
    extern int (*mhdl_Simulate_fptr_0[])();
    return mhdl_Simulate_fptr_0[g_dynamic_phases]();
}

int pvmx_Simulate()
{
    extern int (*pvmx_Simulate_fptr_0[])();
    return pvmx_Simulate_fptr_0[g_dynamic_phases]();
}

int vhmc_Simulate(simtime_t runtime)
{
    extern int in_simulate;
    int status = 0; 
    in_simulate = 0;
    return status;
}

unsigned int gNumOfSignals() { return 30;}
unsigned int gNumOfDerivedSignals() { return 0;}
#ifdef __cplusplus
}
#endif
